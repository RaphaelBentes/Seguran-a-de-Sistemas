# segura
